/Users/gribaudo/VulkanSDK/1.2.198.1/macOS/bin/glslc PhongShader.vert -o PhongVert.spv
/Users/gribaudo/VulkanSDK/1.2.198.1/macOS/bin/glslc PhongShader.frag -o PhongFrag.spv
/Users/gribaudo/VulkanSDK/1.2.198.1/macOS/bin/glslc SkyBoxShader.vert -o SkyBoxVert.spv
/Users/gribaudo/VulkanSDK/1.2.198.1/macOS/bin/glslc SkyBoxShader.frag -o SkyBoxFrag.spv
/Users/gribaudo/VulkanSDK/1.2.198.1/macOS/bin/glslc TextShader.vert -o TextVert.spv
/Users/gribaudo/VulkanSDK/1.2.198.1/macOS/bin/glslc TextShader.frag -o TextFrag.spv
